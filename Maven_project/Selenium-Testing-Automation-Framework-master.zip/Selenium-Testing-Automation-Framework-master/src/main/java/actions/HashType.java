package main.java.actions;
/**
 * The HashType class is an enum class for hash type
 *
 * @author Shilpashree_V
 * @version 1.0
 * @since February 2015
 * 
 */
public enum HashType {
	MD5, SHA1;
}
